//
//  texture.cpp
//  image_synthesis
//
//  Created by 李镇 on 3/7/16.
//  Copyright © 2016 zl. All rights reserved.
//

#pragma once

#include <cstdio>
#include <cstdlib>
#include "color.h"
#include <iostream>

#define PI 3.1415927

using namespace std;

class Texture{
    unsigned char *pixmap;
public:
    int width = 0;
    int height = 0;
    
    Texture(string filename){
        const char* file_name = filename.c_str();
        FILE* fp = fopen(file_name, "rb");
        if (fp == NULL) {
            perror("file_name");
            throw "Argument Exception";
        }
        unsigned char info[54];
        unsigned char throw_away[84];
        // read the 54-byte header
        fread(info, sizeof(unsigned char), 54, fp);
        fread(throw_away, sizeof(unsigned char), 84, fp);
        
        // extract image height and width from header
        width = *(int*)&info[18];
        height = *(int*)&info[22];
//        cout << "width: " << width << endl;
//        cout << "height: " << height << endl;
        
        // allocate 3 bytes per pixel, read the rest of the data at once
        int size = 3 * width * height;
        pixmap = new unsigned char[size];
        
        fread(pixmap, sizeof(unsigned char), size, fp);
        fclose(fp);
        
        for(int i = 0; i < size; i += 3)
        {
            unsigned char tmp = pixmap[i];
            pixmap[i] = pixmap[i+2];
            pixmap[i+2] = tmp;
        }
    }
    
    Color GetColorSphere(double theta, double phi){
        double x = theta /(2 * PI) * width;
//        cout << theta << endl;
//        cout << x << endl;
        
        double y = phi / PI * height;
//        cout << phi << endl;
//        cout << y << endl;
        
        int pre = (int)y * width + (int)x;
//        cout << x << " " << y << endl;
//        cout << "//////////" << endl;
        //return Color(0xff0000);
        return Color(pixmap[3 * pre], pixmap[3 * pre + 1], pixmap[3 * pre + 2]);
    }
    
    Color GetColorPlane(double x, double y){
        int pre = (int)y * width + (int)x;
        return Color(pixmap[3 * pre], pixmap[3 * pre + 1], pixmap[3 * pre + 2]);
    }
};