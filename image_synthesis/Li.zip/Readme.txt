The environment background image is too large to be uploaded to WebAssign.

Please check my Github for the code and image: 

https://github.com/liz425/RayTracer

Images are placed under path "RayTracer/image_synthesis/Release/"

